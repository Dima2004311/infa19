a1 = [5,20]
a2 = [5,20]
a = 133
[a] + a1 #If we add number to the list, we will see that only one list has changed
[133, 5, 20]
#Or
b = 1111
[b] + a2 #If we add number to the list, we will see that only one list has changed
[1111, 5, 20]
