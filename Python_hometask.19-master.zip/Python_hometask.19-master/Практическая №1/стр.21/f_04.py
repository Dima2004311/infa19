a_1, *a_2, a_3 = (1, [6, 2, 3, 4], 5)
>>> print(a_1)
1
>>> print(a_2)
[[6, 2, 3, 4]]
>>> print(a_3)
5
>>>
#Thanks to the square brackets, we can highlight the value for a particular variable in the tuple
