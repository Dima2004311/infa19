x,y,z = ([33, 21, 2], 7, 66)
print(x)
[33, 21, 2]
>>> print(y)
7
>>> print(z)
66
>>>
print(x,y,z)
[33, 21, 2] 7 66
#Using square brackets we can highlight the value of which is equal to the variable
