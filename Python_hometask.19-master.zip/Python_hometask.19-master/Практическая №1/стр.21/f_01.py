ac_1 #variable identifier is correct because IDLE editors are highlighted in black
2ba #CHANGE INDICATOR CANNOT START WITH NUMBERS
x-1 #You cannot use mathematical signs in IDENTIFIER
-z_1 #You cannot use mathematical signs in IDENTIFIER
