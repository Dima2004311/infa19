a, b, c, d =(100, 61, 55)
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    a, b, c, d =(100, 61, 55)
ValueError: not enough values to unpack (expected 4, got 3)
# Which means that number to this value, another number is missing for the variable D
