m = 2.3 + 106 * 4
print(m)
