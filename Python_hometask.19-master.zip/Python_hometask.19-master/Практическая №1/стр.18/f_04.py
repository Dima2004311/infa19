a = int(input('Ведите катет a = '))
b = int(input('Ведите катет b = '))
S = (a * b) / 2
 print(S)
