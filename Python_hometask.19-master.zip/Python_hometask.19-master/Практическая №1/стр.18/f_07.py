S = int(118)
X1 = int(8.30)
U = int(60)
U2 = int(80)
U3 = int(120)
T1 = (S / U) + 8.30
T2 = (S / U2) + 8.30
T2 = (S / U3) + 8.30
V = (T1 + T2 + T3) / 3
V = (T1 + T2 + T3) / 3
T3 = (S / U3) + 8.30
V = (T1 + T2 + T3) / 3
print(V)
#I don’t know if it’s right, therefore, I took three speeds at which the bus could ride and so calculated how much the bus would be in the VINNYTSIA
