#Integer division
m = 10 // 2
>>> print(m)
5

#Modulo division
m = 10 % 2
>>> print(m)
0
