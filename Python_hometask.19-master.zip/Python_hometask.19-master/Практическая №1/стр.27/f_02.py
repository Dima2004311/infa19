# Multiplication through an arithmetic operator
a = 5
>>> b = 3
>>> m = 5 * 3
>>> print(m)

# Adding for arithmetic operator
15
>>> m1 = 5 + 3
>>> print(m1)
8
