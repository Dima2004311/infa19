a = 5
>>> b = 7
>>> m = a < b
>>> print(m)
True
>>> m1 = a > b
>>> print(m1)
False
