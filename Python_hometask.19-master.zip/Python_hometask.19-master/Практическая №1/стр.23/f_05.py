bool("процесор")
True

'''
You can also translate others into other types of variables int("12")
12
>>> str(37)
'37'
'''
