int(41.5), int("60"), int("F", 16)
(41, 60, 15) #because int only considers numbers
>>> (41, 60, 15) #And f it translates the system of calculus

#I didn’t want to put hashtags on all the lines on the Internet, it’s written that it’s also possible
'''
>>> int('ff', 16)
255
>>> int('FF', 16)
255
>>> int('f', 16)
15
>>> int('10', 2)
2
>>> int('10')
10
>>> int('10', 10)
10
'''
