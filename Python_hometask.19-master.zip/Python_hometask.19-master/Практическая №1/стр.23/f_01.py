s = "Python"
>>> s = 21
>>> type(sk_1)
Traceback (most recent call last):
  File "<pyshell#4>", line 1, in <module>
NameError: name 'sk_1' is not defined #It is not possible to determine the type of variable because such variables do not emerge
  type(sk_1)
>>> type(s) #But the variable S is probably because it was already specified earlier
<class 'int'>
