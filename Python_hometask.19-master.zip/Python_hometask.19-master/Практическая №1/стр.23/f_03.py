list("40, 22, 5, 66")
['4', '0', ',', ' ', '2', '2', ',', ' ', '5', ',', ' ', '6', '6']
#This is not correct because comas are on the list
list("40 22 5 66")
['4', '0', ' ', '2', '2', ' ', '5', ' ', '6', '6']
#This is how it will be right
