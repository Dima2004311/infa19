m = 37 + 29.7
>>> print(m)
66.7
# Or
 a = 37
>>> b = 29.7
>>> m = a + b
>>> print(m)
66.7
