int("A", 47)
Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    int("A", 47)
ValueError: int() base must be >= 2 and <= 36, or 0

#I don’t know why not translate please explain in the lesson
#There are all number systems from 1 to 16 number systems  0, 1, 2, 3, 4, 5, 6, 7, 8, 9, A, B, C, D, E, F
#
